from django.apps import AppConfig


class IpaddrConfig(AppConfig):
    name = 'ipaddr'
