from django.contrib import admin
from .models import IpInfo

admin.site.register(IpInfo)