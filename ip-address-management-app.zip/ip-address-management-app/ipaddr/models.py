from django.db import models

# Create your models here.
class IpInfo(models.Model):
    ip_address  = models.CharField(max_length=15)
    status      = models.CharField(max_length=10)
    created_at  = models.DateTimeField(auto_now_add=True)
    modified_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.ip_address
