from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.http import Http404

from .serializers import IpInfoSerializer
from .models import IpInfo


class IpInfoList(APIView):
    """
    List of all IP Addresses, or create new IP Address
    """
    def get(self, request, format=None):
        """
        Return the list of all IP along with status
        """
        ip_addresses = IpInfo.objects.all()
        serializer = IpInfoSerializer(ip_addresses, many=True)
        return Response(serializer.data)

    def post(self, request, format=None):
        """
        Create new IP or list of IP's with the status 'available'
        """
        # set the default status available
        request.data['status'] = 'available'

        # pass data to serializer and check if it is valid or not
        serializer = IpInfoSerializer(data=request.data)
        if serializer.is_valid():
            # verify the IP address value to confirm if it is single or multiple
            if "/" in request.data['ip_address']:
                # parse the IP address value to decide the range needs to be save into the database
                ip_address = request.data['ip_address'].split("/")
                base_ip = ip_address[0].split(".")[:-1]
                base_ip = ".".join(base_ip)
                from_ip = ip_address[0].split(".")[-1]
                to_ip   = ip_address[1]
                new_ip_addresses = []
                old_ip_addresses = []
                # throw the error if it is invalid IP address range
                if from_ip >= to_ip:
                    return Response(
                        {"detail": "Incorrect values has been provided."}, 
                        status=status.HTTP_400_BAD_REQUEST
                    )
                # insert or update IP address into database
                for i in range(int(from_ip), int(to_ip)+1):
                    # check if record is already exists or not
                    if IpInfo.objects.filter(ip_address=f"{base_ip}.{i}").exists():
                        ip_addr_obj = IpInfo.objects.get(ip_address=f"{base_ip}.{i}")
                        ip_addr_obj.status = request.data['status']
                        ip_addr_obj.save()

                        old_ip_addresses.append(IpInfo(ip_address=f"{base_ip}.{i}", status=request.data['status']))

                        continue

                    new_ip_addresses.append(IpInfo(ip_address=f"{base_ip}.{i}", status=request.data['status']))
                # insert bulk record
                if len(new_ip_addresses) > 0: IpInfo.objects.bulk_create(new_ip_addresses)
                serializer = IpInfoSerializer(new_ip_addresses + old_ip_addresses, many=True)
            else:
                serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class IpInfoDetail(APIView):
    """
    Retrieve, update or delete a IP Address.
    """
    def get_object(self, pk):
        """
        fetch single record or throw an error if record not found
        """
        try:
            return IpInfo.objects.get(pk=pk)
        except IpInfo.DoesNotExist:
            raise Http404

    def get(self, request, pk, format=None):
        """
        return single record
        """
        ip_address = self.get_object(pk)
        serializer = IpInfoSerializer(ip_address)
        return Response(serializer.data)

    def put(self, request, pk, format=None):
        """
        Update existing record
        """
        ip_address = self.get_object(pk)
        serializer = IpInfoSerializer(ip_address, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk, format=None):
        """
        Delete existing record
        """
        ip_address = self.get_object(pk)
        ip_address.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
