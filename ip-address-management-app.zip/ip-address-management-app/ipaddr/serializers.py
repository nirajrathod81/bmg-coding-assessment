from rest_framework import serializers
from .models import IpInfo

class IpInfoSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model = IpInfo
        fields = ('ip_address', 'status')